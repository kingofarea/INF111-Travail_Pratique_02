#include "constantes_globales.h" //DEPLACEMENT_Y
#include "m_util_dialogue.h" // Bo�tes de saisie.
#include "t_boite.h" // NB_COLONNES, NB_LIGNES_MAX
#include "winBGIm.h" //  WHITE, 
#include <limits.h> //INT_MIN
#include "t_disjoncteur.h" // AMPERAGES_PERMIS, NB_AMPERAGES_TRAITES

/*
* Module qui permet l'interaction avec l'utilisateur dans le projet pour
* saisir et valider tension, amp�rage, ligne, colonne et demande.
*/

// Retourne une paire (colonne-ligne) valide via les param�tres.
void obtenir_position_valide(int x, int y, 
                             int* colonne, int* ligne, 
                             int position_msg){

     /*
     * Strat�gie : On lit les valeurs en commen�ant � 1 alors il faut
     * soustraire 1 pour concorder avec le tableau de disjoncteurs.

     */

                       
    *colonne = 
        boite_saisie_entier_valide_xy("Entrez la colonne du disjoncteur",
                                      x, y,
                                      1, NB_COLONNES,
                                      position_msg,
                                      WHITE, WHITE);

     // Si l'utlisateur n'a pas annul�.
     if(*colonne != INT_MIN){

         (*colonne)--;

         *ligne = 
             boite_saisie_entier_valide_xy("Entrez la position du disjoncteur",
                                           x, y + DEPLACEMENT_Y,
                                           1, NB_LIGNES_MAX,
                                           position_msg,
                                           WHITE, WHITE);

         if(*ligne != INT_MIN){
             (*ligne)--;
         }
     }

}


/*
* Fonction  pour saisir et valider la tension d'un disjoncteur. 
*/
int tension_valide(int x, int y, int position_msg) {

    int tension;

    do{
        tension = 
            boite_saisie_entier_valide_xy("Entrez la tension du disjoncteur",
                                          x, y,
                                          TENSION_PHASE, TENSION_ENTREE,
                                          position_msg,
                                          WHITE, WHITE);

    }while(tension != INT_MIN && 
        tension != TENSION_ENTREE &&
        tension != TENSION_PHASE);

    return tension;
}

/*
* Fonction pour saisir et valider l'amp�rage d'un disjoncteur. 
*/
int ampere_valide(int x, int y, int position_msg) {

    int ampere = 0;

    //� �crire

    return ampere;
}

