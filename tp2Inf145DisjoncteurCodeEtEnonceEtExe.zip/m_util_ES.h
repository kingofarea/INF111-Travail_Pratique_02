/*
* Module qui permet l'interaction avec l'utilisateur dans le projet pour
* saisir et valider tension, amp�rage, ligne, colonne et demande.
*/

// Retourne une paire (colonne-ligne) valide via les param�tres
// Si l'utilisateur annule, les valeurs retourn�es sont INT_MIN.
void obtenir_position_valide(int x, int y, 
                             int* colonne, int* ligne, 
                             int position_msg);


/*
* Fonction pour saisir et valider la tension d'un disjoncteur. 
* La tension est TENSION_PHASE ou TENSION_ENTREE, rien d'autres.
*/
int tension_valide(int x, int y, int position_msg);

/*
* Fonction locale pour saisir et valider l'amp�rage d'un disjoncteur.
* L'amp�re une des valeurs possibles d�crites dans le tableau 
* AMPERAGES_POSSIBLES d�fini dans t_disjoncteur.h"
*/
int ampere_valide(int x, int y, int position_msg);