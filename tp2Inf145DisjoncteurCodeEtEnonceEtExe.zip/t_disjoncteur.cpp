#include "t_disjoncteur.h"
#include <stdlib.h>

// Retourne un disjoncteur cr�er en allocation dynamique et initialis�.
t_disjoncteur* nouveau_disjoncteur(int ampere, int tension){

    //� �crire

    return NULL;
}    


// Retourne la puissance maximum possible pour ce disjoncteur.
int puissance_max(const t_disjoncteur* disjoncteur){

    return 0;
}

