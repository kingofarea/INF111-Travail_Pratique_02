/*
* Module qui permet la gestion d'une bo�te �lectrique
* avec disjoncteurs.
*
* La boite doit d'abord �tre initialis�e au nombre de Amp�re voulu.
*
* Le projet ne contient qu'une seule bo�te.  Tous les sous- 
* programmes public (.h) agissent sur la m�me bo�te.
*/
#include "t_boite.h"
#include "winBGIm.h"
#include "mtwister.h"

// Ajouter les SP manauqants.

//Retourne la consommation totale de la bo�te.
double consommation_totale(const t_boite* boite){

    double  total = 0;


    return total;

}

//Retourne la puissance totale consomm�e sur les disjoncteurs.
double puissance_total_boite(const t_boite* boite){

    double total = 0;


    return total;

}

// Retourne le temps de support de la charge.
double temps_ups(const t_boite* boite){

    return 0;
}

// Retourne le nombre de disjoncteurs actuellement dans la boite.
int nb_disjoncteurs_actuel(const t_boite* boite){

    int nb = 0;

    return nb;
}


// Retourne le nombre de disjoncteurs de la tension fournie 
// actuellement dans la boite.
int nb_disjoncteurs_tension(const t_boite* boite, int tension){

    int nb = 0;

    return nb;
}


