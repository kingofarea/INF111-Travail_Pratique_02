/*
* Tp2 Boite de disjoncteurs :  Programme principal fournit avec des 
* sous-programmes � compl�ter. 
*
* Dans le cadre du cours INF145.  
* Voir �nonc� fourni pour plus de d�tails.
*
* semestre : A16
* Auteur du code : Pierre B�lisle (copyright 2016);
* D'apr�s une id�e de David Beaulieu sugg�r� par Hugues Saulnier.  
* Tous deux charg�s de cours � l'�ts.
*/
#include <stdlib.h> // EXIT_SUCCESS
#include <float.h> // DBL_MIN
#include <limits.h> // INT_MIN

#include "constantes_globales.h"

#include "t_boite.h" // Types et SP.

#include "m_graphique.h" // Dessin de la boite en mode graphique.

#include "winBGIm.h" // Graphique Windows.

#include "m_util_dialogue.h" // Boites de dialogue.

#include "mtwister.h" // G�n�rateurs al�atoires.

#include "m_util_ES.h" // Fonctions de saisie et de validation.

/*******************
* CONSTANTES
*******************/
// Taille en pixels par d�faut.
// � modifier si settextstyle est utilis� pour 
// changer la police de caract�res.
#define TAILLE_CAR 8

// Espace gauche et droite.
#define GAP_DROITE 2 * TAILLE_CAR
#define GAP_GAUCHE TAILLE_CAR

// Sert � l'appel d'initwindow.
#define PLEIN_X 1000
#define PLEIN_Y 800

// Pourcentage d'une bo�te remplie au d�part.
#define POURC_REMPLI .60

// Pourcentage de volt == TENSION_ENTREE.
#define POURC_TENSION_ENTREE 30

/*******************
* PROTOTYPES
*******************/
// Remplit la boite avec des disjoncteurs s�lectionn�s au hasard
// � partir des constantes POURC_REMPLI et POURC_TENSION_ENTREE.
void remplir_boite(t_boite* boite);

// D�clenche l'ajout d'un disjoncteur dans la bo�te.
void ajouter_disjoncteur(t_boite* boite);

// D�clenche l'ajout d'une demande sur un circuit.
void ajouter_demande(t_boite* boite);

// Affiche les options du menu selon POS_MENU_X et POS_MENU_Y.
void afficher_menu();

// Distribue la t�che � effectuer sur la bo�te selon le choix.
void effectuer_tache(char choix, t_boite* boite);

// �crit les donn�es de la bo�te dans un fichier texte.
void sauvegarder_texte(const t_boite* boite);

// D�clenche la sauvegarde d'une bo�te dans un fichier binaire.
void sauvegarder_boite(const t_boite* boite);

// D�clenche la r�cup�ration d'une bo�te d'un fichier binaire
// et remplit la boite re�u en param�tre, par r�f�rence.
void recuperer_boite(t_boite* boite);

int main(void){

    // Plein �cran.  Doit �tre fait avant d'utiliser getmaxx et getmaxy.
    // initwindow ne tient pas compte des param�tre et 
    // ouvre plein �cran (bogue winbgim).
    initwindow(PLEIN_X, PLEIN_Y);

    // Les constantes locales �vite d'appeler 
    // plusieurs fois getmax() et getmaxy().
    const int TAILLE_X = getmaxx();
    const int TAILLE_Y = getmaxy();
    const int MILIEU_X = TAILLE_X / 2;
    const int MILIEU_Y = TAILLE_Y / 2;

    // Initialisation du germe al�atoire.
    mt_srand(time(NULL));

    // Choix de l'utilisateur.
    char choix;

    cleardevice();

    // Amp�rage demand� � l'utilisateur.
    int max_amperes = 
        boite_saisie_entier_valide_xy("Entrez l'amp�rage de la bo�te",
                                       DIALOGUE_X, DIALOGUE_Y,
                                       AMPERE_TOTAL_MIN, AMPERE_TOTAL_MAX,
                                       HAUT_CENTRE,
                                       WHITE, WHITE);
    // Si l'utilisateur n' pas annul�.
    if(max_amperes != INT_MIN){

        // On obtient un bo�te vide.  Vous devez remplacer {0} par
        // un appel � votre SP qui obtient une bo�te neuve avec le
        // bon nombre d'amp�res et les disjonceturs � NULL.
        t_boite boite = {0};

        // Remplit la bo�te avec quelques disjoncteurs
        // selon les constantes POURC_REMPLI et POURC_TENSION_ENTREE.
        //  Abr�ge la saisie de donn�es de d�part.
        // Sert � commencer avec un bo�te quelconque si aucune r�cup�ration
        // n'a �t� effectu�e. 
        remplir_boite(&boite);

        // Tant que l'utilisateur le d�sire (ESC pour quitter).
        do{

            afficher_boite(&boite);

            afficher_menu();

            choix = getch_graph();

        // Le distributeur de t�ches.
        effectuer_tache(choix, &boite);

    }while (choix != ESC);

    // Le fichier texte est sauvegard� seulement � la fin du programme.
    sauvegarder_texte(&boite);
    }

    closegraph();

    return EXIT_SUCCESS;
}


// Affiche les options du menu selon POS_MENU_X et POS_MENU_Y.
void afficher_menu(){

    outtextxy(POS_MENU_X,POS_MENU_Y,
        "Options du menu : "
        "1: Ajouter un disjoncteur "
        "2: Ajouter/Retirer une puissance � un disjoncteur"
        "3: Sauvegarder 4: R�cup�rer");
}

// Distribue la t�che � effectuer sur la bo�te selon le choix.
void effectuer_tache(char choix, t_boite* boite){

    /*
    * Utilisation de switch-case si possible (bonne pratique).
    */

    // Rien n'est effectu� si le choix ne fait pas partie du menu.
    switch(choix)
    {
    case '1': ajouter_disjoncteur(boite);break;
    case '2': ajouter_demande(boite);break;
    case '3': sauvegarder_boite(boite);break;
    case '4': recuperer_boite(boite);

    }
}


/*
* Remplit la boite avec des disjoncteurs s�lectionn�s au hasard
* � partir des constantes POURC_REMPLI et POURC_TENSION_ENTREE.
*/
void remplir_boite(t_boite* boite){   

   MessageBox( 0, "� �crire", "Remplir une boite al�atoirement", 0 );

}



// D�clenche l'ajout d'un disjoncteur.
void ajouter_disjoncteur(t_boite* boite){
    
    MessageBox( 0, "� �crire", "Ajouter un disjoncteur", 0 );
}

// D�clenche le branchement d'un appareil sur un circuit.
void ajouter_demande(t_boite* boite){
   
    MessageBox( 0, "� �crire", "Ajouter une demande", 0 );
}

// �crit les donn�es de la bo�te dans un fichier texte.
void sauvegarder_texte(const t_boite* boite){

     MessageBox( 0, "� �crire", "Sauvegarder dans un fichier texte", 0 );

}

// D�clenche la sauvegarde d'une bo�te.
void sauvegarder_boite(const t_boite* boite){

     MessageBox( 0, "� �crire", "Sauvegarder dans un fichier binaire", 0 );
}

// D�clenche la r�cup�ration d'une bo�te d'un fichier
// binaire et remplit la boite re�u en param�tre, par r�f�rence.
void recuperer_boite(t_boite* boite){

     MessageBox( 0, "� �crire", "R�cup�rer d'un fichier binaire", 0 );
}
